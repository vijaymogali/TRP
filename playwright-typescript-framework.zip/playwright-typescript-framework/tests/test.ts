import test from "../src/utils/fixtures";
import ENV from "../src/utils/env"
test("test", async ({ page, login }) => {
     await page.goto(ENV.BASE_URL);
    await login.acceptCookies();
    await login.clickFunctionalIntermediary();
    await login.clickCountry("Canada")
})