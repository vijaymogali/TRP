import type { PlaywrightTestConfig } from '@playwright/test';

const config: PlaywrightTestConfig = {
  testMatch: ["tests/test.ts"],
  timeout: 12* 60*1000,
  reporter: "html",
  use: {
    headless: false,
    screenshot: "on",
    video: "on"
  },
  globalSetup: "src/utils/globalSetup.ts"
};

export default config;
